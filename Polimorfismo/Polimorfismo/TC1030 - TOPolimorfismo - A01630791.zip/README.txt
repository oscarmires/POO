TC1030 - TOPolimorfismo - A01630791

Para compilar:

g++ -std=c++17 main.cpp Envio.cpp Paquete.cpp Persona.cpp Sobre.cpp


Discusión sobre polimorfismo:

Esta cualidad del paradigma de POO se ve aplicada en la clase Envio y sus subclases, la cual tiene algunos métodos declarados con la palabra virtual, la cual permite que las clases que se derivan de esta sobreescribirlos.